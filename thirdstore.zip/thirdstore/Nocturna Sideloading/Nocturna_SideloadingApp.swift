//
//  Nocturna_SideloadingApp.swift
//  Nocturna Sideloading
//
//  Created by Jaxon Hensch on 2024-03-04.
//

import SwiftUI

@main
struct Nocturna_SideloadingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
