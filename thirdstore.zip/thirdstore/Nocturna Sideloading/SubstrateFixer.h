// SubstrateFixer.h
#import <Foundation/Foundation.h>

void FixSubstrate(NSString *tweakPath);
